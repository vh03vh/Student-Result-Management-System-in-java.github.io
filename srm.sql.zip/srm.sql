-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 12, 2022 at 11:03 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `srm`
--

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `rollNo` varchar(15) NOT NULL,
  `algo` varchar(3) default NULL,
  `ana` varchar(3) default NULL,
  `si` varchar(3) default NULL,
  `logi` varchar(3) default NULL,
  `stm` varchar(3) default NULL,
  PRIMARY KEY  (`rollNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`rollNo`, `algo`, `ana`, `si`, `logi`, `stm`) VALUES
('10001', '12', '13', '12', '13', '11'),
('10002', '11', '17', '16', '15', '11'),
('10003', '10', '13', '11', '8', '14'),
('10004', '12', '4', '7', '14', '14'),
('10005', '12', '19', '00', '18', '13'),
('10006', '2', '14', '7', '1', '4'),
('10007', '12', '14', '15', '1', '3'),
('10008', '10', '9', '12', '6', '13'),
('10009', '12', '11', '4', '6', '9'),
('10010', '9', '6', '12', '10', '11'),
('10016', '11', '12', '11', '9', '7');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `rollNo` varchar(15) NOT NULL,
  `course` varchar(20) default NULL,
  `branch` varchar(20) default NULL,
  `name` varchar(100) default NULL,
  `gender` varchar(10) default NULL,
  `fatherName` varchar(100) default NULL,
  PRIMARY KEY  (`rollNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`rollNo`, `course`, `branch`, `name`, `gender`, `fatherName`) VALUES
('10001', 'B.tech', 'MN', 'SAMAD KAWLA', 'Female', 'SAMAD'),
('10002', 'B.tech', 'MATH ', 'safaa belkhier', 'Female', 'athman belkhier'),
('10003', 'B.tech', 'INFO', 'DABOUZ MALIKA', 'Female', 'DABOUZ AHMED'),
('10004', 'B.tech', 'INFO', 'kanza sefrani', 'Female', 'sefrani ahmed'),
('10005', 'B.tech', 'MATH ', 'Linda', 'Female', 'ali'),
('10006', 'B.tech', 'INFO', 'sanaa khalifa', 'Female', 'ali mohamed khalifa'),
('10007', 'B.tech', 'INFO', 'Zmmeit  Yamina', 'Female', 'Zmmeit'),
('10008', 'B.tech', 'INFO', 'souraya mailoudi', 'Female', 'salah mailoudi'),
('10009', 'B.tech', 'INFO', 'hadil sayad', 'Female', 'ahmed sayad'),
('10010', 'B.tech', 'INFO', 'Douha Belkhier', 'Female', 'ATHMAN BELKHIER'),
('10013', 'B.tech', 'MATH ', 'ines', 'Female', 'ahmed'),
('10016', 'B.tech', 'MATH ', 'sami', 'Male ', 'ahmed');
